# Handoff: Vaultr UI Redesign ("Command" direction)

## Overview
A visual redesign of the Vaultr finance/accounting web app (Next.js + Tailwind, Supabase).
It modernizes every screen around one system: kill the narrow mobile-first single column
on desktop, lead each screen with a money/status band, surface what needs action, and use
an evolved green + gold palette with a tighter type scale. It also defines the iOS
(portrait) and iPadOS (portrait + landscape) web-app layouts.

## 🔒 Handoff requirements — functionality-safe (MANDATORY)
These are hard rules. Follow them exactly.

1. **Work on a git branch** (e.g. `redesign`) and **commit as you go**, screen by screen.
   Do NOT hand back a fresh unversioned copy — the reviewer needs old-vs-new diffs. One
   commit per screen (or per logical chunk) with clear messages.
2. **Change presentation only.** Keep every component's `useState`/`useReducer`, `useEffect`,
   event handlers, form-submit logic, data fetching, and all Supabase/API calls **exactly as
   they are**. Restyle and re-lay-out the markup (JSX structure, className, inline styles,
   Tailwind); do not rewrite, reorder, or remove the logic that makes things work.
3. **Do NOT edit `lib/`, `app/api/`, or `supabase/` (migrations).** That's the logic and data
   layer. If a design change seems to require touching them, **list it separately in
   CHANGES.md instead of changing it** — the owner will handle those.
4. **Preserve routes/URLs.** If you split or merge pages, keep the old URLs working: list every
   route that moved and add a redirect from the old path to the new one. Update the sidebar nav
   (`components/AppShell.tsx`), `dynamic()` imports, and any hard-coded links. **Leave print
   routes intact** (paths like `/…/[id]/print`).
5. **`npx tsc --noEmit` must pass** before the work is considered done.
6. **Provide `CHANGES.md`** summarizing: which pages were split/merged; which routes were
   added/removed/moved (with their redirects); which components were renamed or moved; and
   every place you had to touch logic (ideally: none).

If any design detail conflicts with rules 2–4, **keep the functionality/route and flag it in
CHANGES.md**. Presentation is negotiable; behavior and data are not.

## ⚠️ About the design files — READ FIRST
`Vaultr Dashboard Redesign.dc.html` is a **design reference**, not production code.
It is a static HTML/inline-style prototype (a streaming "Design Component") showing the
intended look and behavior. **Do not paste it into the app.**

Your task: **recreate these designs inside the EXISTING Vaultr codebase** — same Next.js
app, same React components, same Supabase data hooks, same Tailwind config and CSS
variables in `app/globals.css`. This is a **restyle/relayout only**:

- **Do NOT change any functionality, data fetching, state, routing, or business logic.**
  Every handler, query, mutation, and prop that exists today must keep working exactly as-is.
- Change only markup structure, layout, className/inline styles, spacing, and the token
  values in `globals.css` / `tailwind.config.ts`.
- Work screen-by-screen. After each screen, confirm the page still builds and all existing
  interactions (add/edit/delete, filters, mark-paid, reconcile, tab nav, ⌘K search,
  dark-mode toggle) behave identically.
- The redesign's nav is the SAME nav that already exists in `components/AppShell.tsx`
  (Dashboard, Accounts, Transactions, Budget & Insights · Customers, Suppliers, Payroll,
  Organization, Templates · Profitability, Forecast, Cards, TDS, Setup, Settings). Do not
  add or remove destinations.

If a design detail conflicts with existing functionality, **keep the functionality** and
flag it.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and layout are final. Recreate pixel-close
using the codebase's existing components and Tailwind/CSS-variable system. The prototype uses
Lucide icons — the app already uses `lucide-react`, so reuse those exact icon names.

## Design tokens (evolved from current `globals.css`)
The redesign keeps the forest-green brand and adds a warm gold accent. Update the CSS
variables in `app/globals.css`; the app already consumes `var(--*)` widely so most screens
inherit the new look automatically.

### Light theme
```
--bg:#F4F7F4;  --surface:#FFFFFF;  --surface-2:#EFF3EF;  --surface-3:#E9EFEA;
--border:#E2E9E3;  --border-2:#EDF1ED;
--text:#0E1A12;  --text-muted:#55655A;  --text-faint:#93A499;
--brand:#2A7A50;  --brand-deep:#123A26;  --brand-light:#E4F1E9;
--accent:#B7822F;  --accent-light:#F6EEDD;      /* NEW warm gold accent */
--income:#1F9E54;  --expense:#C8372A;  --transfer:#3B82F6;  --amber:#C08A3E;
--shadow:0 1px 2px rgba(15,26,18,.04), 0 8px 24px rgba(15,26,18,.05);
--shadow-lg:0 20px 50px rgba(15,26,18,.14);
```
### Dark theme
```
--bg:#0E140F;  --surface:#161E17;  --surface-2:#1E271F;  --surface-3:#232E24;
--border:#2A362B;  --border-2:#222D23;
--text:#E9F1EA;  --text-muted:#93A897;  --text-faint:#5E7A63;
--brand:#3DA86A;  --brand-deep:#0C2A1B;  --brand-light:#17301F;
--accent:#D9A24E;  --accent-light:#2A2416;
--income:#3EC876;  --expense:#E8584A;  --transfer:#60A5FA;  --amber:#D9A24E;
--shadow:0 1px 2px rgba(0,0,0,.3), 0 8px 24px rgba(0,0,0,.35);
--shadow-lg:0 20px 50px rgba(0,0,0,.5);
```

### Typography
- Family: **Manrope** (Google Fonts, weights 400/500/600/700/800). This replaces the
  current `-apple-system` stack. Add the `<link>` in `app/layout.tsx` and set it as the
  sans family in `tailwind.config.ts`, OR keep the system stack if you prefer no font change —
  the layouts work with either.
- Numbers use `font-variant-numeric: tabular-nums; letter-spacing:-.01em` (the `.num` class).
- Scale: page H1 23px/800; card titles 13.5–14px/800; body 12.5–13px; section labels
  10–11px/700–800 uppercase with `.06–.13em` tracking; big money 22–40px/800.

### Radii / spacing
- Cards: 16–20px radius, `1px solid var(--border)`, `var(--shadow)`. Bands/heroes: 18–20px.
- Pills/badges: 20px radius. Buttons: 10–12px radius, min-height 44px on touch layouts.
- Grid gaps 12–16px; page padding 26–30px desktop.

## Information architecture — RESTRUCTURED (do this)
The redesign consolidates the old 15-item nav into **9 destinations in 4 groups**. Related
work now lives together (like Customers already holds Incoming). Update
`components/AppShell.tsx` nav to:

```
Home            (was Dashboard)            → /dashboard
Transactions                              → /transactions   (Fetch = tab)
Accounts                                  → /accounts       (tabs: Balances · Cards · Subscriptions)
Insights                                  → /insights       (tabs: Budgets · Profitability · Forecast)
── SALES & PURCHASES ──
Customers                                 → /customers      (tabs: Overview · Directory · Invoices · Incoming · TDS)
Suppliers                                 → /suppliers      (tabs: Overview · Directory · Invoices · Fetch)
── TEAM ──
Payroll                                   → /payroll/processing (tabs: Processing · Staff · History · Slips)
Organization                              → /organization   (tabs: Companies · Employees · Contracts)
── (bottom) ──
Settings                                  → /setup          (two-pane: Profile · Appearance · Company · Email · Categories · Account types · Currencies · Export · Templates · Downloads)
```
Sub-items expand under the active top item in the sidebar (see the prototype). The active
state must resolve for nested routes (e.g. `/cards` highlights Accounts → Cards).

### Pages MERGED (and the redirects to add — rule 4)
Keep every existing route working; add `redirects()` in `next.config.ts` (or route-level
redirects) from old paths to the new hub + tab. **This is a nav/label consolidation — you may
keep the underlying page components mounted as tab panels rather than deleting them.**

| Old route | New location | Redirect |
|---|---|---|
| `/budget-insights` | `/insights` (Budgets tab) | 308 → `/insights` |
| `/profitability` | `/insights?tab=profitability` | 308 → `/insights` |
| `/forecast` | `/insights?tab=forecast` | 308 → `/insights` |
| `/cards` | `/accounts` (Cards tab) | 308 → `/accounts` |
| `/subscriptions` | `/accounts` (Subscriptions tab) | 308 → `/accounts` |
| `/recoverables/tds` | `/customers` (TDS tab) | keep + surface as tab |
| `/customers/commission` | `/customers` (Incoming tab) | keep + surface as tab |
| `/templates`, `/downloads` | under Settings | keep routes, add to Settings nav |

If merging a route is more than a nav/redirect change (i.e. would require touching data or
API code), **do NOT do it — list it in CHANGES.md** and leave it as its own route for now.
Prefer shipping the nav regrouping + redirects first; deep component merges are optional.

Prototype badges for the hubs: **14a Insights**, **14b Accounts**. All other badges map to the
tab *contents* that now live inside these hubs.

## The system (apply to every screen)
1. **Header row**: page H1 + one-line subtitle (left), primary action button (right).
2. **Status band** at top: either a dark `--brand-deep` gradient hero (Net Worth / To collect /
   To pay / Payable) or a light stat-tile strip (all-time credits/debits, etc.). One
   brand-accented tile per strip max.
3. **Action zone** ("Needs attention") above the fold where relevant: urgent items use
   `--expense` tint, warnings use `--accent-light` gold; each has a one-tap CTA.
4. **Content**: full-width tables (columnar, date/group headers, right-aligned tabular
   numbers) and/or a bento grid. Replace narrow `max-w-2xl` single columns.
5. **Detail rail** instead of modals where it improves triage (see Transactions).
6. **Tabs**: segmented control on `--surface-2` with the active tab on `--surface` + shadow.
7. **Status pills**: paid/sent = green `#DCFCE7/#14532D`; overdue/cancelled = red
   `#FEE2E2/#991B1B`; pending/draft = amber `#FEF3C7/#92400E`.

## Screens / Views (badge → target route/component)
Each screen in the prototype carries a badge (e.g. `2a`). Map to the real file:

- **1a / 1b Dashboard** → `components/dashboard/DashboardClient.tsx`. Use **1b "Command"**:
  full-width dark "pulse band" (Net Worth · Income · Expenses · Leftover · Profit MTD), then a
  bento grid — tall "Needs attention" feed (card dues, unbilled, budget-over) on the left,
  5-month trend + circular credit-utilisation gauge + top-spend donut + compact budgets,
  then recent transactions. Keep all existing props/data (accounts, cardDues, budgets,
  payeeRings, profitMTD, etc.).
- **2a Transactions** → `components/transactions/TransactionsClient.tsx` + `TransactionItem.tsx`.
  Full-width: stat strip (all-time credits/debits/net + July net-flow w/ sparkline), toolbar
  (search + segmented type filter + account dropdown + advanced filter), date-grouped columnar
  list, and a persistent **detail rail** on the right replacing `TransactionDetail` modal.
  Keep all filters, multi-select/bulk-delete, add/edit flows.
- **3a Accounts** → `components/accounts/AccountsClient.tsx` + `AccountCard.tsx`. Net-worth
  band + accounts grouped by type in a 2-col card grid; credit cards show utilisation bars;
  keep reconcile badges + inline reconcile panel.
- **3b Cards** → `components/cards/CardsClient.tsx`. Summary tiles + per-card row = credit-card
  visual (gradient, masked number) beside statement-cycle stats (statement amount, remaining
  due, utilisation) + Pay + bank-match/hidden-charge status. Keep cycle math + pay modal.
- **4a Budget & Insights** → `components/budgets/BudgetsClient.tsx`. Summary band + progress-ring
  grid per category (over = red ring) + plain-language insight cards.
- **4b Profitability** → `components/profitability/ProfitabilityClient.tsx`. Expected / Actual /
  Outstanding cards (in/out/net), source breakdown (inwards/outwards), net-profit history bars.
- **5a Customers** → `components/customers/CustomersClient.tsx`. Receivables band + tabs
  (Overview/Directory/Invoices/Incoming) + directory table + ageing rail + top-debtor.
- **5b Suppliers** → `components/suppliers/*`. Payables band + tabs + next-due table w/ recurring pills.
- **6a Payroll Processing** → `components/payroll/processing/ProcessingListClient.tsx`. Status
  band + month ledger table; keep status filter + create-month.
- **6b Forecast** → `components/forecast/ForecastClient.tsx`. Runway projection chart + weekly
  timeline cards (tight weeks outlined red) + low-balance warning. Keep the week/item data model.
- **7a Setup / Settings** → `components/settings/SettingsClient.tsx` + `app/(app)/setup/*`. Two-pane
  preferences: section list (Profile, Appearance, Company, Email, Categories, Account types,
  Currencies, Export) + content pane. **11d** shows the Company pane.
- **8a Customers → Directory**, **8b Customers → Invoices** (Couriers/Reimbursables/Invoices sub-tabs
  from `InvoicesTabsBar` + customer chip picker + `UnifiedInvoicesClient` list), **8c Suppliers → Invoices**
  (`SupplierInvoicesClient` + tabs + bulk pay).
- **9a Organization → Companies**, **9b Organization → Employees**, **9c TDS**
  (`recoverables/tds/TDSClient.tsx`, pending/settled grouped by customer), **9d Customers → Incoming**
  (`commission/CommissionClient.tsx`, PO/ETD/status pills).
- **10a Couriers**, **10b Reimbursables**, **10c Transactions → Fetch**
  (`txn-inbox/TransactionInboxClient.tsx` — email drafts w/ confidence %, approve/reject),
  **10d Suppliers → Fetch**.
- **11a Payroll → Staff** (`payroll/staff/StaffClient.tsx`), **11b Payroll → Slips**
  (`payroll/slips/SlipsClient.tsx`), **11c Organization → Contracts**
  (`organization/ContractsClient.tsx`), **11d Setup → Company**.
- **13a Subscriptions** (`subscriptions/SubscriptionsClient.tsx`), **13b Templates**
  (`templates/TemplatesHubClient.tsx` — doc-type tabs + template list + live preview),
  **13c Downloads** (`app/(app)/downloads`).

## Responsive / iOS + iPadOS (badges 12a–12c)
- **iPhone portrait (12a)**: single column; bottom tab bar (Home / Txns / center + Add /
  Cards / More) replaces the sidebar drawer; respect `env(safe-area-inset-*)`; all tap
  targets ≥44px; status-bar padding at top.
- **iPad portrait (12b)**: collapse sidebar to a 70px **icon rail**; content reflows to
  1–2 columns; the pulse band becomes a 2×2 grid.
- **iPad landscape (12c)**: full sidebar (≈210–236px) + desktop-parity content.
- Implement with Tailwind responsive prefixes + the existing `AppShell` desktop/mobile split;
  add an iPad (`md`–`lg`) branch. The current left-edge swipe drawer stays for iPhone.

## Interactions & behavior (unchanged from today)
Reuse every existing behavior: ⌘K global search, dark-mode toggle (`data-theme` on
`<html>` + `localStorage 'inex-theme'`), add-transaction modal, per-row menus, mark-paid,
reconcile, bulk delete, tab routing, chip pickers, email-fetch approve/reject. The redesign
only restyles their containers.

## Assets
- `assets/vaultr-letter-logo.png` — the INEX wordmark used in the sidebar/headers (already in
  `public/vaultr-letter-logo.png`). In dark mode the prototype renders it white via
  `filter:brightness(0) invert(1)`.
- Icons: `lucide-react` (already a dependency). Category glyphs use the app's existing emoji map.

## Files in this bundle
- `Vaultr Dashboard Redesign.dc.html` — the full design reference (open in a browser; ~30
  screen frames + 3 device frames, light/dark toggle top-right).
- `support.js` — runtime needed to render the .dc.html reference locally.
- `assets/` — logo images used by the reference.

## How to open the reference
Serve the folder over any static server (e.g. `npx serve .`) and open the `.dc.html` file —
it needs `support.js` alongside it. Use the light/dark button (top-right) to check both themes.
