# CHANGES.md — template for the implementer

Fill this in as you build the redesign on the `redesign` branch. It is the old-vs-new map the
owner will review. The redesign intent is below; record what you actually did.

## Pages split / merged (intended)
- **Insights** = merge of `/budget-insights` + `/profitability` + `/forecast` into `/insights`
  with tabs (Budgets · Profitability · Forecast) and a shared summary band.
- **Accounts** absorbs `/cards` and `/subscriptions` as tabs (Balances · Cards · Subscriptions).
- **Customers** surfaces Incoming (`/customers/commission`) and TDS (`/recoverables/tds`) as tabs.
- **Settings** (`/setup`, two-pane) absorbs Templates and Downloads into its section list.

## Routes added / removed / moved (fill in with the redirect you added)
| Old route | New location | Redirect added? | Notes |
|---|---|---|---|
| /budget-insights | /insights (Budgets) |  |  |
| /profitability | /insights (Profitability tab) |  |  |
| /forecast | /insights (Forecast tab) |  |  |
| /cards | /accounts (Cards tab) |  |  |
| /subscriptions | /accounts (Subscriptions tab) |  |  |
| /recoverables/tds | /customers (TDS tab) |  | keep route, add tab |
| /customers/commission | /customers (Incoming tab) |  | keep route, add tab |
| /templates | Settings nav |  | route unchanged |
| /downloads | Settings nav |  | route unchanged |

- Print routes (`/…/[id]/print`): **left intact** (confirm).

## Components renamed / moved
- (list here)

## Logic touched (should be NONE)
- If you had to touch any `useState`/`useEffect`/handler/fetch/Supabase call, or anything in
  `lib/`, `app/api/`, `supabase/`, record it here with the reason. Otherwise write "None".

## Verification
- [ ] `npx tsc --noEmit` passes
- [ ] Dark-mode toggle works on every screen
- [ ] All existing interactions verified (add/edit/delete, filters, mark-paid, reconcile,
      bulk delete, tab nav, ⌘K search, email-fetch approve/reject)
- [ ] Every old URL still resolves (redirects or same route)
